export enum TodoEnum {
  storeModule = "todo"
}

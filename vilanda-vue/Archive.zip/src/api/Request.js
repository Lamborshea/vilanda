import todolist from "@/api/request/todolist/index";
import login from "@/api/request/login/index";
export default {
  todolist,
  login
};

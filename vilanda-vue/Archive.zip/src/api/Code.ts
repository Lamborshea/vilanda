export const SUCCESS = 20000;

import todolist from "@/api/url/todolist/index";
import login from "@/api/url/login/index";
export default {
  todolist,
  login
};

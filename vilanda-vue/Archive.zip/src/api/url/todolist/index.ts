export default {
  getTodo: "/todolist/all",
  addTodo: "/todolist/add",
  updateTodo: "/todolist/update",
  deleteTodo: "/todolist/delete"
};

export default {
  login: "/login",
  register: "/login/register"
};

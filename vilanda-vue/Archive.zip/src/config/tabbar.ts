export let tabbar = [
  {
    title: "Todo",
    to: {
      name: "todo"
    },
    icon: "certificate"
  },
  {
    title: "Search",
    to: {
      name: "search"
    },
    icon: "search"
  },
  {
    title: "Home",
    to: {
      name: "home"
    },
    icon: "home-o"
  },
  {
    title: "Wechat",
    to: {
      name: "wechat"
    },
    icon: "friends-o"
  },
  {
    title: "Settings",
    to: {
      name: "settings"
    },
    icon: "setting-o"
  }
];

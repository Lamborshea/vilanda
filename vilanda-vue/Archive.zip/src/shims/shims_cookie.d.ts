declare module "js-cookie" {
  const Cookies: Object;
  export default Cookies;
}

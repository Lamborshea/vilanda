declare module "md5" {
  const md5: Function;
  export default md5;
}

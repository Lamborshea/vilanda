<template>
  <div>wechat</div>
</template>
<script lang="ts">
/**
 *
 * @author 谢南波
 */
import { Vue, Component, Prop, Model, Watch } from "vue-property-decorator";
import { State, Getter, Action, Mutation } from "vuex-class";
@Component({
  components: {}
})
export default class App extends Vue {}
</script>
<style lang="scss" scoped>
</style>

export const CLEAR_ALL = "clearAll";

export const GET_TABBAR = "getTabbar";

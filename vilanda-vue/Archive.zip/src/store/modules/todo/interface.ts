export interface ToDoState {
  todoList: Array<any>;
}

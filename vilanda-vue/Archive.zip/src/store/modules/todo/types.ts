export const CLEAR_ALL = "clearAll";

export const GET_TODO_LIST = "getTodoList";

export const FETCH_TODO_LIST = "fetchTodoList";

export const ADD_TODO = "addTodo";

export const UPDATE_TODO = "updateTodo";

export const DELETE_TODO = "deleteTodo";

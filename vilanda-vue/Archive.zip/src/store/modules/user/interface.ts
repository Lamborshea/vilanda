export interface UserState {
  _id: string;
  username: string;
  password: string;
  avatar: string;
}

export const CLEAR_ALL = "clearAll";

export const STORE_USER_INFO = "storeUserInfo";

export const GET_USER_INFO = "getUserInfo";

export const LOGIN = "login";

export const REGISTER = "register";

export const LOGOUT = "logout";
